# Mohammad Divan R. H.Omar - Portfolio

Single-page portfolio website for a Licensed Civil Engineer specializing in Quantity Surveying, Cost Estimation and Tendering.

Built with plain HTML, CSS and JavaScript (no build step). Icons use Font Awesome and fonts use Google Fonts, both loaded from CDNs.

## Structure

```
index.html                  Page markup (all sections)
css/style.css               Styles (design tokens are CSS variables at the top)
js/main.js                  Menu, scroll animations, skill bars, contact form
assets/images/              Project pictures
assets/Divan_HOmar_Resume.pdf   CV used by the "Download CV" button
```

## Publish with GitHub Pages

1. Create a new GitHub repository and upload all of these files, keeping the folder structure.
2. Go to **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then **Save**.
4. After a minute, the site is live at `https://<your-username>.github.io/<repository-name>/`.

## Editing

- Skill percentages: change the `data-level` value and the percentage text in `index.html` (Skills section).
- Colors: edit the variables under `:root` in `css/style.css`.
- Replace the CV: overwrite `assets/Divan_HOmar_Resume.pdf` with the same file name.
