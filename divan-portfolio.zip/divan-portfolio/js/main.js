/* Mobile menu toggle */
const navLinks = document.getElementById('navLinks');
document.getElementById('menuBtn').addEventListener('click', () => navLinks.classList.toggle('open'));
navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));
document.getElementById('year').textContent = new Date().getFullYear();

/* Scroll reveal + skill bar fill */
const io = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (!e.isIntersecting) return;
    e.target.classList.add('show');
    const bar = e.target.querySelector('.bar span');
    if (bar) bar.style.width = bar.dataset.level + '%';
    io.unobserve(e.target);
  });
}, { threshold: .12 });
document.querySelectorAll('.reveal').forEach((el, i) => {
  el.style.transitionDelay = (i % 4) * 80 + 'ms';
  io.observe(el);
});

/* Active nav link while scrolling */
const links = [...navLinks.querySelectorAll('a')];
const spy = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) links.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#' + e.target.id));
  });
}, { rootMargin: '-45% 0px -50% 0px' });
document.querySelectorAll('main section[id]').forEach(s => spy.observe(s));

/* Contact form: opens the visitor's email app (no backend needed) */
document.getElementById('contactForm').addEventListener('submit', ev => {
  ev.preventDefault();
  const n = document.getElementById('name').value, f = document.getElementById('email').value, m = document.getElementById('message').value;
  window.location.href = 'mailto:divanhomar11@gmail.com?subject=' + encodeURIComponent('Portfolio inquiry from ' + n) +
    '&body=' + encodeURIComponent(m + '\n\nFrom: ' + n + ' (' + f + ')');
  document.getElementById('formNote').textContent = 'Thank you! Your email app should open to send the message.';
});
